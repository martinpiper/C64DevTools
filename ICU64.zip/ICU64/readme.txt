
ICU64 for VICE 2.3 v0.1.2
-------------------------

REQUIREMENTS:

- Microsoft Windows XP/Vista/7 (32-bit or 64-bit)

- Microsoft .NET Framework 2.0 (in case of Windows XP)

- WinVICE 2.3 x86


INSTALLATION:

- Install VICE 2.3

- Copy the files 'ICU64.EXE', 'ICU64.INI' and 'x64mm.exe' to the VICE folder

- (optional) Create a shortcut to the dekstop for the 'ICU64.EXE'


RUN:

- Start ICU64 (the x64mm should start automatically)

- Press F1 for help (works in the main menu and in most of the other windows)


GOOD HACKS!

~Mathfigure 2012.10.28

